<?php
$_['text_title']           = 'Укрпочта';
$_['text_express_w2w']     = 'Укрпочта Экспресс — отделение';
$_['text_express_w2d']     = 'Укрпочта Экспресс — курьер';
$_['text_standard_w2w']    = 'Укрпочта Стандарт — отделение';
$_['text_standard_w2d']    = 'Укрпочта Стандарт — курьер';
$_['text_free']            = 'бесплатно';
$_['text_city']            = 'Населённый пункт';
$_['text_office']          = 'Отделение';
$_['text_postcode']        = 'Почтовый индекс';
$_['text_street']          = 'Улица';
$_['text_house']           = 'Дом';
$_['text_apartment']       = 'Квартира';
$_['text_select_city']     = 'Начните вводить название города';
$_['text_select_office']   = 'Выберите отделение';
